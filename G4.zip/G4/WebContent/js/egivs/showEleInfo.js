/**
 * 显示电梯信息
 */
	$.ajax({
        url : "queryBaseInfo.query",
        dataType : "json",
        type : "post",
        timeout : 5000,
        success : showresult,
        error : function() {
        	console.log(XMLHttpRequest.responseText); 
        	console.log(XMLHttpRequest.status);
        	console.log(XMLHttpRequest.readyState);
        	console.log(textStatus); 
        	console.log("error");
        }
    });
	function showresult(data){
	var jsonData = data;
	
    var cs = new table({
        "tableId":"cs_table",    //必须 表格id
        "headers":["电梯设备编号","电梯注册代码","电梯使用责任单位","电梯所在区域","电梯制造单位"],   //必须 thead表头 parseInt(data_index)
        "data":data,         //必须 tbody 数据展示
        "displayNum": 20,    //必须   默认 10  每页显示行数
        "groupDataNum":1,     //可选    默认 10  组数
        "display_tfoot":true, // true/false  是否显示tfoot --- 默认false
        "bindContentTr":function(){ //可选 给tbody 每行绑定事件回调
            this.tableObj.find("tbody").on("click",'tr',function(){
                //return false;
                //alert(jsonData[2]['faultid']);
                var tr_index = $(this).data("tr_index");        // tr行号  从0开始
                var data_index = $(this).data("data_index");   //数据行号  从0开始
                //var faultid="[{\"faultid\":"+$(this).closest('tr').children().eq(0).text()+"}]";
                var eleid="[{\"eleid\":"+data[parseInt(data_index)]['hide_data']+"}]";
				$.ajax({
						url : "queryDetails.query",
				        dataType : "json",    
				        type : "post",
				        data:"eleid="+eleid,
				        timeout : 1000,
				        success : showResult,
				        error : function(XMLHttpRequest, textStatus, errorThrown) {
				        	 alert(XMLHttpRequest.status);
				        	 alert(XMLHttpRequest.readyState);
				        	 alert(textStatus);
				        	   }
				    });
				 function showResult(data){
					 	var jsonResult = data;
					 	//$col = $("<td>增加的列</td>");  
				        //$("#cs_table>tbody>tr").append($col);
						var $content=$("<div id='inner-bd'>"
								+"<div  class='tab-wraper'>"
								+"<ul class='tab'>"
								+"<li class='current'><a>电梯信息查看/编辑</a></li>"
								+"</ul>"
								+"</div><form action='updateEle.add' method='post'>"
								+" <table class='kv-table'>" 
								+"<input type='hidden' name='eleid' value='"+jsonResult[0]['eleid']+"'/>"
				       			+"<tr><td class='kv-label'>电梯设备编号：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='eleno'  disabled='true' style='border:1px' value='"+jsonResult[0]['eleno']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯注册代码：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='eleregistationno'  disabled='true' style='border:1px' value='"+jsonResult[0]['eleregistationno']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯使用单位内部编号：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='eleequipmentno'  disabled='true' style='border:1px' value='"+jsonResult[0]['eleequipmentno']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯类型：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='eletype'  disabled='true' style='border:1px' value='"+jsonResult[0]['eletype']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯制造时间：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='elemadetime' class='datepicker' disabled='true' style='border:1px' value='"+jsonResult[0]['elemadetime']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯使用单位：</td>"+"<td class='kv-content'><input type='text' class='form-control' name='eleappliedname'  disabled='true' style='border:1px' value='"+jsonResult[0]['eleappliedname']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯制造单位：</td>"+"<td class='kv-content'><input type='text' class='form-control' name='elemadename'  disabled='true' style='border:1px' value='"+jsonResult[0]['elemadename']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯维保单位：</td>"+"<td class='kv-content'><input type='text' class='form-control' name='eleservicedname'  disabled='true' style='border:1px' value='"+jsonResult[0]['eleservicedname']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯质检单位：</td>"+"<td class='kv-content'><input type='text' class='form-control' name='eleinspectedname'  disabled='true' style='border:1px' value='"+jsonResult[0]['eleinspectedname']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯报修电话：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='elemainttel'  disabled='true' style='border:1px' value='"+jsonResult[0]['elemainttel']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯应急电话：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='eleemergencytel'  disabled='true' style='border:1px' value='"+jsonResult[0]['eleemergencytel']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯所在区域：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='elearea'  disabled='true' style='border:1px' value='"+jsonResult[0]['elearea']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯安装地址：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='eleaddress'  disabled='true' style='border:1px' value='"+jsonResult[0]['eleaddress']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯状态：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='elestate'  disabled='true' style='border:1px' value='"+jsonResult[0]['elestate']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯额定速度：</td>"+"<td class='kv-content'><input type='text' class='form-control' name='elearatedspeed'  disabled='true' style='border:1px' value='"+jsonResult[0]['elearatedspeed']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>电梯额定载量：</td>"+"<td class='kv-content'><input type='text' class='form-control' name='elearatedload'  disabled='true' style='border:1px' value='"+jsonResult[0]['elearatedload']+"'/></td></tr>"
				       			
				       			+"<tr><td class='kv-label'>保险单号：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='insuno'  disabled='true' style='border:1px' value='"+jsonResult[0]['insuno']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>理赔电话：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='insutel'  disabled='true' style='border:1px' value='"+jsonResult[0]['insutel']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>承保单位：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='insucompany'  disabled='true' style='border:1px' value='"+jsonResult[0]['insucompany']+"'/></td></tr>"
				       			+"<tr><td class='kv-label'>保险截止日期：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='insuduration' class='datepicker' disabled='true' style='border:1px' value='"+jsonResult[0]['insuduration']+"'/></td></tr>"
				       			+"<tr><td><br/>&nbsp;</td></tr>"
				       			+"<tr><td><button type='submit' value='保存' class='btn btn-success'>保存</button>&nbsp;<button type='button' onclick='update()'  class='btn btn-warning' value='修改'>修改</button></td></tr>"
				       			+"</table></form>"
				       			+"</div>"
				       			+"<script>function update(){$('.up').removeAttr('disabled');}</script>");
						
					$('#addTpl').html(" ");
		        	layer.open({
		        		title: '电梯详细信息',
		        		area:['800px','500px'],
		        		content: $('#addTpl').append($content).html(),
		        		btn:['取消']
		        	});
		        	//$('select').select();
				 }
            })
        },
        sort:false,    // 点击表头是否排序 true/false  --- 默认false
        sortContent:[
            {
                index:0,//表头序号
                compareCallBack:function(a,b){ //排序比较的回调函数
                    var a=parseInt(a.id,10);
                    var b=parseInt(b.id,10);
                    if(a < b)
                        return -1;
                    else if(a == b)
                        return 0;
                    else
                        return 1;
                }
            },
            {
                index:3,//表头序号
                compareCallBack:function(a,b){ //排序比较的回调函数
                    var a=parseInt(a.age,5);
                    var b=parseInt(b.age,5);
                    if(a < b)
                        return -1;
                    else if(a == b)
                        return 0;
                    else
                        return 1;
                }
            }
    ],
        /*specialRows:[
            {
                row:4,
                cssText:{
                     "color":"#FFCF17"
                }
            }
        ],*/
        search:true   // 默认为false 没有搜索
    });
}
