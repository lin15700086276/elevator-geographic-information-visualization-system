/**
 * 
 */
$(document).ready(function(){  //查询电梯基本信息
	$.ajax({
            url : "queryAllFault.query",
            dataType : "json",
            type : "post",
            timeout : 5000,
            success : showresult,
            error : function() {
            	console.log(XMLHttpRequest.responseText); 
            	console.log(XMLHttpRequest.status);
            	console.log(XMLHttpRequest.readyState);
            	console.log(textStatus); 
            	console.log("error");
            }
        });
	function showresult(data){
		var jsonData = data;
		var Count = jsonData.length;//记录条数  
		//var Count = 100;
		var PageSize=20;//设置每页示数目  
		var PageCount=Math.ceil(Count/PageSize);//计算总页数  
		var currentPage =1;//当前页，默认为1。 
		var isHiddenExist = 0;
		//var back='<a href="#" class="page_prev back-one" > &lt;</a>';  
		//$('#page').append(back);	 
		for(var i=1;i<=PageCount;i++){
			var pageN='<a href="#" class="pagenum current'+i+'" selectPage="'+i+'" >'+i+'</a>';
			$('#page').append(pageN); 
		}
	
		$(".current1").addClass("page_current");    	
		$("#faultBase").html('');
		var queryleft="<button id='detail'  class='btn btn-success faultdetail' value=\" ";
		var queryright=" \" >查看详情/编辑</button>";
 		var delleft="<button id='detail'  class='btn btn-danger delfault' value=\" ";
		var delright=" \" >删除</button>";
		for(var i=(currentPage-1)*PageSize;i<PageSize*currentPage;i++){
	        	 $("#faultBase").append("<tr><td><input type='checkbox' class='cbr' /></td>"
					+"<td>&nbsp"+jsonData[i]['eleregistation']+"</td>"
	        		+"<td>&nbsp"+jsonData[i]['faulttype']+"</td>"
	        		+"<td>&nbsp"+jsonData[i]['faultdescribe']+"</td>"
	        		+"<td>&nbsp"+jsonData[i]['faultsolvetime']+"</td>"
	        		+"<td>"+queryleft+jsonData[i]['faultid']+queryright+"</td>"
        			//+"<td>"+delleft+jsonData[i]['faultid']+delright+"</td></tr>"
        	 );
		}
		//-------------------------------------设置页码点击事件----------------------------------------
		$('a').click(function(){
			 //$(id).attr("checked", false).checkboxradio("refresh");
			 /*if($(this).hasClass('.back-one')){
				 var selectPage=$(".page_current").attr('selectPage')-1;  
			 }
			 else if($(this).hasClass('.next-one')){
				 var selectPage=$(".page_current").attr('selectPage')+1; 
			 }*/
			 var selectPage=$(this).attr('selectPage');
			 $("#eleInfo").html(' ');
			 $(".pagenum").removeClass("page_current");
			 $(".current"+selectPage).addClass("page_current");
			 for(var i=(selectPage-1)*PageSize;i<PageSize*selectPage;i++){ 
				 $("#faultBase").append("<tr><td><input type='checkbox' class='cbr' /></td>"
							+"<td>&nbsp"+jsonData[i]['eleregistation']+"</td>"
			        		+"<td>&nbsp"+jsonData[i]['faulttype']+"</td>"
			        		+"<td>&nbsp"+jsonData[i]['faultdescribe']+"</td>"
			        		+"<td>&nbsp"+jsonData[i]['faultsolvetime']+"</td>"
			        		+"<td>"+queryleft+jsonData[i]['faultid']+queryright+"</td>"
		        			//+"<td>"+delleft+jsonData[i]['faultid']+delright+"</td></tr>"
		        	);
				 if(i>Count-1) {
				    	break;
				    }
			 }
	    	 jQuery(document).ready(function($){
		        	var $state = $(".table-bordered thead input[type='checkbox']"),
		        	$chcks = $(".table-bordered tbody input[type='checkbox']");
		        	$state.on('change', function(ev){
			        	if($state.is(':checked')){
			        		$chcks.prop('checked', true).trigger('change');
			        	}
			        	else{
			     			$chcks.prop('checked', false).trigger('change');
			        	}
		        	});
		      });
	    	 /*$(".checkinfo").unbind("click").click(function(){//电梯详细信息
				 var eleid="[{\"eleid\":"+$(this).val()+"}]";
				 $.ajax({
				        url : "queryDetails.query",
				        dataType : "json",
				        type : "post",
				        data:"eleid="+eleid,
				        timeout : 1000,
				        success : showResult,
				        error : function(XMLHttpRequest, textStatus, errorThrown) {
				        	 alert(XMLHttpRequest.status);
				        	 alert(XMLHttpRequest.readyState);
				        	 alert(textStatus);
				        	   }
				    });
					function showResult(data){
		        		 $(".btn").unbind("click").click(function(){
		     				$('#content').load("ele_query.jsp");
		         		 });
						console.log(data);
						var jsonResult = data;
						$("#content").empty("");
						$("#content").append("<div id='inner-bd'>"
								+"<div  class='tab-wraper'>"
								+"<ul class='tab'>"
								+"<li class='current'><a>电梯信息查看/编辑</a></li>"
								+"</ul>"
								+"</div>"
								+" <table class='kv-table'>" 	
				       			+"<tr><td class='kv-label'>电梯设备编号：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleno']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯注册代码：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleregistationno']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯使用单位内部编号：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleequipmentno']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯类型：</td>"+"<td class='kv-content'>"+jsonResult[0]['eletype']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯制造时间：</td>"+"<td class='kv-content'>"+jsonResult[0]['elemadetime']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯使用单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleappliedname']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯制造单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['elemadename']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯维保单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleservicedname']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯质检单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleinspectedname']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯报修电话：</td>"+"<td class='kv-content'>"+jsonResult[0]['elemainttel']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯应急电话：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleemergencytel']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯所在区域：</td>"+"<td class='kv-content'>"+jsonResult[0]['elearea']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯安装地址：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleaddress']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯状态：</td>"+"<td class='kv-content'>"+jsonResult[0]['elestate']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯额定速度：</td>"+"<td class='kv-content'>"+jsonResult[0]['elearatedspeed']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯额定载量：</td>"+"<td class='kv-content'>"+jsonResult[0]['elearatedload']+"</td></tr>"	
				       			+"<tr><td class='kv-label'>保险单号：</td>"+"<td class='kv-content'>"+jsonResult[0]['insuno']+"</td></tr>"
				       			+"<tr><td class='kv-label'>理赔电话：</td>"+"<td class='kv-content'>"+jsonResult[0]['insutel']+"</td></tr>"
				       			+"<tr><td class='kv-label'>承保单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['insucompany']+"</td></tr>"
				       			+"<tr><td class='kv-label'>保险截止日期：</td>"+"<td class='kv-content'>"+jsonResult[0]['insuduration']+"</td></tr>"
				       			+"</table>"
				       			+"</div>"
				       	 );
					}
	    		 //$('iframe', parent.document).attr('src', "ele_details.jsp?eleid=100");
			 });*/
	    	 $(".faultdetail").unbind("click").click(function(){		
	    		 var faultid="[{\"faultid\":"+$(this).val()+"}]";
				 $.ajax({
				        url : "getFaultDetailInfo.query",
				        dataType : "json",
				       
				        type : "post",
				        data:"faultid="+faultid,
				        timeout : 1000,
				        success : showResult,
				        error : function(XMLHttpRequest, textStatus, errorThrown) {
				        	 alert(XMLHttpRequest.status);
				        	 alert(XMLHttpRequest.readyState);
				        	 alert(textStatus);
				        	   }
				    });
				 function showResult(data){
					 	var jsonResult = data;
						var $content=$("<div id='inner-bd'>"
								+"<div  class='tab-wraper'>"
								+"<ul class='tab'>"
								+"<li class='current'><a>电梯信息查看/编辑</a></li>"
								+"</ul>"
								+"</div>"
								+"<table class='kv-table'>" 	
				       			+"<tr><td class='kv-label'>电梯注册代码：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleregistation']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障类型：</td>"+"<td class='kv-content'>"+jsonResult[0]['faulttype']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障原因：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultreason']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障描述：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultdescribe']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障时间：</td>"+"<td class='kv-content'>"+jsonResult[0]['faulttime']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障监测来源：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultdetecsource']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障解决单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultsolvecompany']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障解决时间：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultsolvetime']+"</td></tr>"
				       			+"<tr><td class='kv-label'>救助人数：</td>"+"<td class='kv-content'>"+jsonResult[0]['rescuenum']+"</td></tr>"
				       			+"<tr><td class='kv-label'>报修人：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultreport']+"</td></tr>"
				       			+"<tr><td class='kv-label'>报修人电话：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultreporttel']+"</td></tr>"
				       			+"</table>"
				       			+"<br/>"
				       			+"<button id='back' class='btn btn-secondary btn-sm btn-icon icon-left back'>返回</button>"
				       			+"</div>");
					$('#addTpl').html(" ");
		        	layer.open({
		        		title: '电梯详细信息',
		        		area:['800px','500px'],
		        		content: $('#addTpl').append($content).html(),
		        		btn:['','']
		        	});
		        	//$('select').select();
				 }
	        });
	    	 
	    	 $(".delinfo").unbind("click").click(function(){
	    		 var ifdel=confirm("确认删除？");
	    		 if(ifdel==true){
					 var eleid="[{\"eleid\":"+$(this).val()+"}]";
					 $(this).parent().parent().remove();
					 $.ajax({
					        url : "delEle.add",
					        dataType : "json",
					        type : "post",
					        data:"eleid="+eleid,
					        timeout : 1000,
					        success : deleteEle,
					        error : function(XMLHttpRequest, textStatus, errorThrown) {
					        	 alert(XMLHttpRequest.status);
					        	 alert(XMLHttpRequest.readyState);
					        	 alert(textStatus);
					        	 }
					    });
						function deleteEle(data){
							alert("删除成功！");
						}
	    		 }

			 });
		});  
		//-------------------------------------设置全选----------------------------------------
    	jQuery(document).ready(function($){
        	var $state = $(".table-bordered thead input[type='checkbox']"),
        	$chcks = $(".table-bordered tbody input[type='checkbox']");
        	$state.on('change', function(ev){
	        	if($state.is(':checked')){
	        		$chcks.prop('checked', true).trigger('change');
	        	}
	        	else{
	     			$chcks.prop('checked', false).trigger('change');
	        	}
        	});
        });
    	
    	$(".faultdetail").unbind("click").click(function(){		
    		var faultid="[{\"faultid\":"+$(this).val()+"}]";
			 $.ajax({
			        url : "getFaultDetailInfo.query",
			        dataType : "json",
			       
			        type : "post",
			        data:"faultid="+faultid,
			        timeout : 1000,
			        success : showResult,
			        error : function(XMLHttpRequest, textStatus, errorThrown) {
			        	 alert(XMLHttpRequest.status);
			        	 alert(XMLHttpRequest.readyState);
			        	 alert(textStatus);
			        	   }
			    });
			 function showResult(data){
				 	var jsonResult = data;
					var $content=$("<div id='inner-bd'>"
								+"<div  class='tab-wraper'>"
								+"<ul class='tab'>"
								+"<li class='current'><a>电梯信息查看/编辑</a></li>"
								+"</ul>"
								+"</div>"
								+"<table class='kv-table'>" 	
				       			+"<tr><td class='kv-label'>电梯注册代码：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleregistation']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障类型：</td>"+"<td class='kv-content'>"+jsonResult[0]['faulttype']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障原因：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultreason']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障描述：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultdescribe']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障时间：</td>"+"<td class='kv-content'>"+jsonResult[0]['faulttime']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障监测来源：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultdetecsource']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障解决单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultsolvecompany']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障解决时间：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultsolvetime']+"</td></tr>"
				       			+"<tr><td class='kv-label'>救助人数：</td>"+"<td class='kv-content'>"+jsonResult[0]['rescuenum']+"</td></tr>"
				       			+"<tr><td class='kv-label'>报修人：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultreport']+"</td></tr>"
				       			+"<tr><td class='kv-label'>报修人电话：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultreporttel']+"</td></tr>"
				       			+"</table>"
				       			+"<br/>"
				       			+"<button id='back' class='btn btn-secondary btn-sm btn-icon icon-left back'>返回</button>"
				       			+"</div>");
				$('#addTpl').html(" ");
	        	layer.open({
	        		title: '电梯详细信息',
	        		area:['800px','500px'],
	        		content: $('#addTpl').append($content).html(),
	        		btn:['','']
	        	});
	        	//$('select').select();
			 }
        });
    	
    	/*$(".checkinfo").unbind("click").click(function(){//电梯详细信息
			 var eleid="[{\"eleid\":"+$(this).val()+"}]";
			 $.ajax({
			        url : "queryDetails.query",
			        dataType : "json",
			       
			        type : "post",
			        data:"eleid="+eleid,
			        timeout : 1000,
			        success : showResult,
			        error : function(XMLHttpRequest, textStatus, errorThrown) {
			        	 alert(XMLHttpRequest.status);
			        	 alert(XMLHttpRequest.readyState);
			        	 alert(textStatus);
			        	   }
			    });
				function showResult(data){
	        		 $(".btn").unbind("click").click(function(){
	     				$('#content').load("ele_query.jsp");
	         		 });
					console.log(data);
					var jsonResult = data;
					$("#content").empty("");
					$("#content").append("<div id='inner-bd'>"
							+"<div  class='tab-wraper'>"
							+"<ul class='tab'>"
							+"<li class='current'><a>电梯信息查看/编辑</a></li>"
							+"</ul>"
							+"</div>"
							+" <table class='kv-table'>" 
							
			       			+"<tr><td class='kv-label'>电梯设备编号：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleno']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯注册代码：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleregistationno']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯使用单位内部编号：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleequipmentno']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯类型：</td>"+"<td class='kv-content'>"+jsonResult[0]['eletype']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯制造时间：</td>"+"<td class='kv-content'>"+jsonResult[0]['elemadetime']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯使用单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleappliedname']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯制造单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['elemadename']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯维保单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleservicedname']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯质检单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleinspectedname']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯报修电话：</td>"+"<td class='kv-content'>"+jsonResult[0]['elemainttel']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯应急电话：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleemergencytel']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯所在区域：</td>"+"<td class='kv-content'>"+jsonResult[0]['elearea']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯安装地址：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleaddress']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯状态：</td>"+"<td class='kv-content'>"+jsonResult[0]['elestate']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯额定速度：</td>"+"<td class='kv-content'>"+jsonResult[0]['elearatedspeed']+"</td></tr>"
			       			+"<tr><td class='kv-label'>电梯额定载量：</td>"+"<td class='kv-content'>"+jsonResult[0]['elearatedload']+"</td></tr>"
			       			
			       			+"<tr><td class='kv-label'>保险单号：</td>"+"<td class='kv-content'>"+jsonResult[0]['insuno']+"</td></tr>"
			       			+"<tr><td class='kv-label'>理赔电话：</td>"+"<td class='kv-content'>"+jsonResult[0]['insutel']+"</td></tr>"
			       			+"<tr><td class='kv-label'>承保单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['insucompany']+"</td></tr>"
			       			+"<tr><td class='kv-label'>保险截止日期：</td>"+"<td class='kv-content'>"+jsonResult[0]['insuduration']+"</td></tr>"
			       			+"</table>"
			       			+"<br/>"
			       			+"<button id='back' class='btn btn-secondary btn-sm btn-icon icon-left back'>返回</button>"
			       			+"</div>"
			       	 );
				}
    			//$('iframe', parent.document).attr('src', "ele_details.jsp");
		 });*/
    	
    	 $(".delinfo").unbind("click").click(function(){
    		 var ifdel=confirm("确认删除？");
    		 if(ifdel==true){
    			 var faultid="[{\"faultid\":"+$(this).val()+"}]";
				 $(this).parent().parent().remove();
				 $.ajax({
				        url : "delFault.add",
				        dataType : "json",
				        type : "post",
				        data:"faultid="+faultid,
				        timeout : 1000,
				        success : deleteEle,
				        error : function(XMLHttpRequest, textStatus, errorThrown) {
				        	 alert(XMLHttpRequest.status);
				        	 alert(XMLHttpRequest.readyState);
				        	 alert(textStatus);
				        	 }
				    });
					function deleteEle(data){
						alert("删除成功！");
					}
    		 }

		 });
	}
});
