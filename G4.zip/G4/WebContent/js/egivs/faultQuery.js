/**
 * 根据注册号查询故障信息
 */
/*$(document).ready(function(){
	var $state = $(".table-bordered thead input[type='checkbox']"),
	$chcks = $(".table-bordered tbody input[type='checkbox']");
	$state.on('change', function(ev){
		if($state.is(':checked')){
			$chcks.prop('checked', true).trigger('change');
		}
		else{
			$chcks.prop('checked', false).trigger('change');
		}
	});
});*/

// $(".faultquery").click(function(){
function queryFaultBase(){
	 var eleregistationno = $("#eleregistrationno").val();
	 console.log(eleregistrationno);
	 $.ajax({
	        url : "getFaultBaseInfo.query",
	        dataType : "json",
	        type : "post",
	        data:"eleregistationno="+eleregistationno,
	        timeout : 5000,
	        success : getBaseInfo,
	        error : function(XMLHttpRequest, textStatus, errorThrown) {
	        	 alert(XMLHttpRequest.status);
	        	 alert(XMLHttpRequest.readyState);
	        	 alert(textStatus);
	        	 }
	    });
		function getBaseInfo(data){
			var cs = new table({
		        "tableId":"cs_table",    //必须 表格id
		        "headers":["电梯设备编号","电梯注册代码","故障类型","故障描述","故障解决时间","电梯所在区域"],   //必须 thead表头 parseInt(data_index)
		        "data":data,         //必须 tbody 数据展示
		        "displayNum": 20,    //必须   默认 10  每页显示行数
		        "groupDataNum":1,     //可选    默认 10  组数
		        "display_tfoot":true, // true/false  是否显示tfoot --- 默认false
		        "bindContentTr":function(){ //可选 给tbody 每行绑定事件回调
		            this.tableObj.find("tbody").on("click",'tr',function(){
		                //return false;
		                //alert(jsonData[2]['faultid']);
		                var tr_index = $(this).data("tr_index");        // tr行号  从0开始
		                var data_index = $(this).data("data_index");   //数据行号  从0开始
		                //var faultid="[{\"faultid\":"+$(this).closest('tr').children().eq(0).text()+"}]";
		                var faultid="[{\"faultid\":"+data[parseInt(data_index)]['hide_data']+"}]";
						$.ajax({
						        url : "getFaultDetailInfo.query",
						        dataType : "json",
						       
						        type : "post",
						        data:"faultid="+faultid,
						        timeout : 1000,
						        success : showResult,
						        error : function(XMLHttpRequest, textStatus, errorThrown) {
						        	 alert(XMLHttpRequest.status);
						        	 alert(XMLHttpRequest.readyState);
						        	 alert(textStatus);
						        	   }
						    });
						 function showResult(data){
							 	var jsonResult = data;
								var $content=$("<div id='inner-bd'>"
										+"<div  class='tab-wraper'>"
										+"<ul class='tab'>"
										+"<li class='current'><a>电梯信息查看/编辑</a></li>"
										+"</ul>"
										+"</div><form action='updateFault.add' method='post'>"
										+"<table class='kv-table'>" 	
										+"<input type='hidden' name='faultid' value='"+jsonResult[0]['faultid']+"'/>"
						       			+"<tr><td class='kv-label'>电梯注册代码：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='eleregistation'  disabled='true' style='border:1px' value='"+jsonResult[0]['eleregistation']+"'/></td></tr>"
						       			+"<tr><td class='kv-label'>电梯故障类型：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='faulttype'  disabled='true' style='border:1px' value='"+jsonResult[0]['faulttype']+"'/></td></tr>"
						       			+"<tr><td class='kv-label'>电梯故障原因：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='faultreason'  disabled='true' style='border:1px' value='"+jsonResult[0]['faultreason']+"'/></td></tr>"
						       			+"<tr><td class='kv-label'>电梯故障描述：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='faultdescribe'  disabled='true' style='border:1px' value='"+jsonResult[0]['faultdescribe']+"'/></td></tr>"
						       			+"<tr><td class='kv-label'>电梯故障时间：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='faulttime'  disabled='true' style='border:1px' value='"+jsonResult[0]['faulttime']+"'/></td></tr>"
						       			+"<tr><td class='kv-label'>电梯故障监测来源：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='faultdetecsource'  disabled='true' style='border:1px' value='"+jsonResult[0]['faultdetecsource']+"'/></td></tr>"
						       			+"<tr><td class='kv-label'>电梯故障解决单位：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='faultsolvecompany'  disabled='true' style='border:1px' value='"+jsonResult[0]['faultsolvecompany']+"'/></td></tr>"
						       			+"<tr><td class='kv-label'>电梯故障解决时间：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='faultsolvetime'  disabled='true' style='border:1px' value='"+jsonResult[0]['faultsolvetime']+"'/></td></tr>"
						       			+"<tr><td class='kv-label'>救助人数：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='rescuenum'  disabled='true' style='border:1px' value='"+jsonResult[0]['rescuenum']+"'/></td></tr>"
						       			+"<tr><td class='kv-label'>报修人：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='faultreport'  disabled='true' style='border:1px' value='"+jsonResult[0]['faultreport']+"'/></td></tr>"
						       			+"<tr><td class='kv-label'>报修人电话：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='faultreporttel'  disabled='true' style='border:1px' value='"+jsonResult[0]['faultreporttel']+"'/></td></tr>"
						       			+"<tr><td><br/>&nbsp;</td></tr>"
						       			+"<tr><td><button type='submit' value='保存' class='btn btn-success'>保存</button>&nbsp;<button type='button' onclick='update()'  class='btn btn-warning' value='修改'>修改</button></td></tr>"
						       			+"</table></form>"
						       			+"<br/>"
						       			+"</div>"
						       			+"<script>function update(){$('.up').removeAttr('disabled');}</script>");
							$('#addTpl').html(" ");
				        	layer.open({
				        		title: '电梯详细信息',
				        		area:['800px','500px'],
				        		content: $('#addTpl').append($content).html(),
				        		btn:['取消']
				        	});
				        	//$('select').select();
						 }
		            })
		        },
		        sort:false,    // 点击表头是否排序 true/false  --- 默认false
		        sortContent:[
		            {
		                index:0,//表头序号
		                compareCallBack:function(a,b){ //排序比较的回调函数
		                    var a=parseInt(a.id,10);
		                    var b=parseInt(b.id,10);
		                    if(a < b)
		                        return -1;
		                    else if(a == b)
		                        return 0;
		                    else
		                        return 1;
		                }
		            },
		            {
		                index:3,//表头序号
		                compareCallBack:function(a,b){ //排序比较的回调函数
		                    var a=parseInt(a.age,5);
		                    var b=parseInt(b.age,5);
		                    if(a < b)
		                        return -1;
		                    else if(a == b)
		                        return 0;
		                    else
		                        return 1;
		                }
		            }
		    ],
		        /*specialRows:[
		            {
		                row:4,
		                cssText:{
		                     "color":"#FFCF17"
		                }
		            }
		        ],*/
		        search:true   // 默认为false 没有搜索
		    });
			/*var jsonData = data;
			$("#cs_table").html('');
			var queryleft="<button id='detail'  class='btn btn-success faultdetail' value=\" ";
    		var queryright=" \" >查看详情/编辑</button>";
     		var delleft="<button id='detail'  class='btn btn-danger delfault' value=\" ";
    		var delright=" \" >删除</button>";
			for(var i=0;i<jsonData.length;i++){
		        	 $("#cs_table").append("<tr><td><input type='checkbox' class='cbr' /></td>"
						+"<td>&nbsp"+jsonData[i]['eleregistation']+"</td>"
		        		+"<td>&nbsp"+jsonData[i]['faulttype']+"</td>"
		        		+"<td>&nbsp"+jsonData[i]['faultdescribe']+"</td>"
		        		+"<td>&nbsp"+jsonData[i]['faultsolvetime']+"</td>"
		        		+"<td>"+queryleft+jsonData[i]['faultid']+queryright+"</td>"
	        			//+"<td>"+delleft+jsonData[i]['faultid']+delright+"</td></tr>"
	        	 );
 			}
			
			$(".faultdetail").unbind("click").click(function(){//电梯详细信息
				 var faultid="[{\"faultid\":"+$(this).val()+"}]";
				 
				 //var faultid=$(this).val();
				 console.log(faultid);
				 $.ajax({
				        url : "getFaultDetailInfo.query",
				        dataType : "json",
				        type : "post",
				        data:"faultid="+faultid,
				        timeout : 5000,
				        success : showResult,
				        error : function(XMLHttpRequest, textStatus, errorThrown) {
				        	 alert(XMLHttpRequest.status);
				        	 alert(XMLHttpRequest.readyState);
				        	 alert(textStatus);
				        	   }
				    });
					function showResult(data){
						console.log(data);
						var jsonResult = data;
						$("#content").empty("");
						$("#content").append("<div id='inner-bd'>"
								+"<div  class='tab-wraper'>"
								+"<ul class='tab'>"
								+"<li class='current'><a>电梯信息查看/编辑</a></li>"
								+"</ul>"
								+"</div>"
								+"<table class='kv-table'>" 	
				       			+"<tr><td class='kv-label'>电梯注册代码：</td>"+"<td class='kv-content'>"+jsonResult[0]['eleregistation']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障类型：</td>"+"<td class='kv-content'>"+jsonResult[0]['faulttype']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障原因：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultreason']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障描述：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultdescribe']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障时间：</td>"+"<td class='kv-content'>"+jsonResult[0]['faulttime']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障监测来源：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultdetecsource']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障解决单位：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultsolvecompany']+"</td></tr>"
				       			+"<tr><td class='kv-label'>电梯故障解决时间：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultsolvetime']+"</td></tr>"
				       			+"<tr><td class='kv-label'>救助人数：</td>"+"<td class='kv-content'>"+jsonResult[0]['rescuenum']+"</td></tr>"
				       			+"<tr><td class='kv-label'>报修人：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultreport']+"</td></tr>"
				       			+"<tr><td class='kv-label'>报修人电话：</td>"+"<td class='kv-content'>"+jsonResult[0]['faultreporttel']+"</td></tr>"
				       			+"</table>"
				       			+"<br/>"
				       			+"<button id='back' class='btn btn-secondary btn-sm btn-icon icon-left back'>返回</button>"
				       			+"</div>"
				       	 );
					}
			});
			 $(".delfault").unbind("click").click(function(){
	    		 var ifdel=confirm("确认删除？");
	    		 if(ifdel==true){
	    			 var faultid="[{\"faultid\":"+$(this).val()+"}]";
					 $(this).parent().parent().remove();
					 $.ajax({
					        url : "delFault.add",
					        dataType : "json",
					        type : "post",
					        data:"faultid="+faultid,
					        timeout : 1000,
					        success : deleteEle,
					        error : function(XMLHttpRequest, textStatus, errorThrown) {
					        	 alert(XMLHttpRequest.status);
					        	 alert(XMLHttpRequest.readyState);
					        	 alert(textStatus);
					        	 }
					    });
						function deleteEle(data){
							alert("删除成功！");
						}
	    		 }

			 });*/
		}
 }