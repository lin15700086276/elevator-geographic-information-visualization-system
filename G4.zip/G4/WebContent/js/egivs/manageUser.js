/**
 * 用户信息管理
 */
$(document).ready(function(){  //查询电梯基本信息
	$.ajax({
            url : "userinfo.do",
            dataType : "json",
            type : "post",
            timeout : 5000,
            success : showresult,
            error : function() {
            	console.log(XMLHttpRequest.responseText); 
            	console.log(XMLHttpRequest.status);
            	console.log(XMLHttpRequest.readyState);
            	console.log(textStatus); 
            	console.log("error");
            }
        });
	function showresult(data){
		jsonData=data;
		$("#userinfo").append("<table class='kv-table'>"
    			+"<tr><td class='kv-label'>用户名：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='username'  disabled='true' style='border:1px' value='"+jsonData['username']+"'/></td></tr>"
    			+"<tr><td class='kv-label'>姓名：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='name'  disabled='true' style='border:1px' value='"+jsonData['name']+"'/></td></tr>"
    			+"<tr><td class='kv-label'>性别：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='gender'  disabled='true' style='border:1px' value='"+jsonData['gender']+"'/></td></tr>"
    			+"<tr><td class='kv-label'>手机号码：</td>"+"<td class='kv-content'><input type='text' class='form-control up' name='telephone'  disabled='true' style='border:1px' value='"+jsonData['usertel']+"'/></td></tr>"
    			+"<tr><td class='kv-label'>公司：</td>"+"<td class='kv-content'><input type='text' class='form-control' name='company'  disabled='true' style='border:1px' value='"+jsonData['company']+"'/></td></tr>"
    			+"<tr><td><br/>&nbsp;</td></tr>"
    			+"<tr><td><button type='submit' value='保存' class='btn btn-success'>保存</button>&nbsp;<button type='button'  onclick='updateuser()' class='btn btn-warning updateuser' value='修改'>修改</button></td></tr>"
    			+"</table>"
    			+"<script>function updateuser(){$('.up').removeAttr('disabled');}</script>"
    	);
	}
});
	